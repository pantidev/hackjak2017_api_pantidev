<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RuangLaktasi extends Model
{
    //
    protected $table = "rptra_merged";
    public $timestamps = false;
}
